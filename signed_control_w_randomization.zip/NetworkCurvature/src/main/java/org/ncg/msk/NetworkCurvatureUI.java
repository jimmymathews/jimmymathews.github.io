package org.ncg.msk;

import javax.swing.JPanel;
import javax.swing.JOptionPane;
import org.gephi.statistics.spi.Statistics;
import org.gephi.statistics.spi.StatisticsUI;
import org.openide.util.lookup.ServiceProvider;

@ServiceProvider(service = StatisticsUI.class)
public class NetworkCurvatureUI implements StatisticsUI {

    private NetworkCurvature statistic;
    private NetworkCurvaturePanel panel;

    @Override
    public JPanel getSettingsPanel() {
        panel = new NetworkCurvaturePanel();
        
        return panel;
    }

    @Override
    public void setup(Statistics ststcs)
    {
        this.statistic = (NetworkCurvature) ststcs;
    }

    @Override
    public void unsetup() {
        if(panel!=null)
        {
            boolean randomizingDirections = false;
            if(!panel.getOnlyControlTypeSelected() && panel.getDirANDControlTypeSelected())
                randomizingDirections = true;
            if(panel.getOnlyControlTypeSelected() && !panel.getDirANDControlTypeSelected())
                randomizingDirections = false;
            if(!panel.getOnlyControlTypeSelected() && !panel.getDirANDControlTypeSelected())
                randomizingDirections = false;

            String message = statistic.setRandomizationOfStuff(panel.getProportions(), randomizingDirections);
            if(message != "Successful randomization setting")
                JOptionPane.showMessageDialog(null, message, message, JOptionPane.ERROR_MESSAGE); 
        }
        
        this.panel = null;
        this.statistic = null;
    }

    @Override
    public Class<? extends Statistics> getStatisticsClass() {
        return NetworkCurvature.class;
    }

    @Override
    public String getValue() {
        if (statistic != null)
            return "" + statistic.getAverageRicciForman();
        return "";
    }

    @Override
    public String getDisplayName() {
        return "Network Curvatures";
    }

    @Override
    public String getCategory() {
        return StatisticsUI.CATEGORY_NETWORK_OVERVIEW;
    }

    @Override
    public int getPosition() {
        return 11000;
    }

    @Override
    public String getShortDescription() {
        return null;
    }
}
