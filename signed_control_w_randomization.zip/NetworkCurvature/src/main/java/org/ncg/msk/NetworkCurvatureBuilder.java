package org.ncg.msk;

import org.gephi.statistics.spi.Statistics;
import org.gephi.statistics.spi.StatisticsBuilder;
import org.openide.util.lookup.ServiceProvider;

@ServiceProvider(service = StatisticsBuilder.class)
public class NetworkCurvatureBuilder implements StatisticsBuilder {

    @Override
    public String getName() {
        return "Network Curvatures";
    }

    @Override
    public Statistics getStatistics() {
        return new NetworkCurvature();
    }

    @Override
    public Class<? extends Statistics> getStatisticsClass() {
        return NetworkCurvature.class;
    }
}