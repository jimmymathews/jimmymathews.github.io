package org.ncg.msk;
import org.ncg.msk.NetworkCurvatureCalculator;
import org.gephi.graph.api.Column;
import org.gephi.graph.api.Graph;
import org.gephi.graph.api.GraphModel;
import org.gephi.graph.api.Node;
import org.gephi.graph.api.Edge;
import org.gephi.graph.api.Origin;
import org.gephi.graph.api.Table;
import org.gephi.statistics.spi.Statistics;

import java.util.regex.Pattern;  
import java.util.regex.Matcher;
import java.util.ArrayList;


public class NetworkCurvature implements Statistics
{
    private NetworkCurvatureCalculator calc = new NetworkCurvatureCalculator();

    @Override
    public void execute(GraphModel graphModel) {
        Graph graph = graphModel.getGraphVisible();
        graph.readLock();

        exportGraphToCalculator(graphModel,calc);
        calc.calculateRicciFormanDirectedUndirected();
        importResults(graphModel,calc);

        graph.readUnlock();

    }

    public void exportGraphToCalculator(GraphModel graphModel, NetworkCurvatureCalculator calc)
    {
        Table nt = graphModel.getNodeTable();
        Table et = graphModel.getEdgeTable();

        //Create data columns if necessary
        boolean needToInitializeWeights = false;
        if(nt.getColumn("Weight") == null || nt.getColumn("Weight").getTypeClass() != Double.class)
        {
            nt.addColumn("Weight", Double.class);
            needToInitializeWeights=true;
        }
        if(nt.getColumn("ricci_forman") == null || nt.getColumn("ricci_forman").getTypeClass() != Double.class)
            nt.addColumn("ricci_forman", Double.class);
        if(et.getColumn("ricci_forman") == null || et.getColumn("ricci_forman").getTypeClass() != Double.class)
            et.addColumn("ricci_forman", Double.class);
        if(nt.getColumn("ricci_forman_directed") == null || nt.getColumn("ricci_forman_directed").getTypeClass() != Double.class)
            nt.addColumn("ricci_forman_directed", Double.class);
        if(et.getColumn("ricci_forman_directed") == null || et.getColumn("ricci_forman_directed").getTypeClass() != Double.class)
            et.addColumn("ricci_forman_directed", Double.class);
        if(nt.getColumn("signed_control") == null || nt.getColumn("signed_control").getTypeClass() != Double.class)
            nt.addColumn("signed_control", Double.class);
        if(et.getColumn("signed_control") == null || et.getColumn("signed_control").getTypeClass() != Double.class)
            et.addColumn("signed_control", Double.class);
        if(nt.getColumn("negative_ricci_forman") == null || nt.getColumn("negative_ricci_forman").getTypeClass() != Double.class)
            nt.addColumn("negative_ricci_forman", Double.class);
        if(et.getColumn("negative_ricci_forman") == null || et.getColumn("negative_ricci_forman").getTypeClass() != Double.class)
            et.addColumn("negative_ricci_forman", Double.class);
        if(nt.getColumn("negative_ricci_forman_directed") == null || nt.getColumn("negative_ricci_forman_directed").getTypeClass() != Double.class)
            nt.addColumn("negative_ricci_forman_directed", Double.class);
        if(et.getColumn("negative_ricci_forman_directed") == null || et.getColumn("negative_ricci_forman_directed").getTypeClass() != Double.class)
            et.addColumn("negative_ricci_forman_directed", Double.class);
        if(nt.getColumn("negative_signed_control") == null || nt.getColumn("negative_signed_control").getTypeClass() != Double.class)
            nt.addColumn("negative_signed_control", Double.class);
        if(et.getColumn("negative_signed_control") == null || et.getColumn("negative_signed_control").getTypeClass() != Double.class)
            et.addColumn("negative_signed_control", Double.class);
        //Grab nodes with weights
        Node[] nodes = graphModel.getGraphVisible().getNodes().toArray();
        for(Node n : nodes)
        {
            Double w = new Double(1.0);
            if(needToInitializeWeights)
                n.setAttribute("Weight",w);
            System.out.println("W "+w.doubleValue());
            w = (Double)n.getAttribute("Weight");
            calc.addNode(w.doubleValue(), n.getStoreId());
        }
        
        //Grab edges with weights
        Edge[] edges = graphModel.getGraphVisible().getEdges().toArray();
        
        if(et.getColumn("ControlType") == null) //Initialize if missing
        {
            et.addColumn("ControlType", String.class);
            for(Edge e : edges)
            {
                e.setAttribute("ControlType","activation");
            }
        }
        
        for(Edge e : edges)
        {             //I think this assumes that the edges are stored as directed edges.
            String control_type = "none";
            control_type = (String)e.getAttribute("ControlType");
            calc.addEdge(e.getSource().getStoreId(), e.getTarget().getStoreId(), e.getWeight(), e.getStoreId(), control_type);
        }
    }
    
    public void importResults(GraphModel graphModel, NetworkCurvatureCalculator calc)
    {
        Edge[] edges = graphModel.getGraphVisible().getEdges().toArray();
        for(Edge e : edges)
        {
            e.setAttribute("ricci_forman", calc.getEdgeById(e.getStoreId()).get("Ricci-Forman"));
            e.setAttribute("ricci_forman_directed", calc.getEdgeById(e.getStoreId()).get("directed Ricci-Forman"));
            e.setAttribute("signed_control", calc.getEdgeById(e.getStoreId()).get("signed-control curvature"));
            e.setAttribute("negative_ricci_forman", -1.0*calc.getEdgeById(e.getStoreId()).get("Ricci-Forman"));
            e.setAttribute("negative_ricci_forman_directed", -1.0*calc.getEdgeById(e.getStoreId()).get("directed Ricci-Forman"));
            e.setAttribute("negative_signed_control", -1.0*calc.getEdgeById(e.getStoreId()).get("signed-control curvature"));

            String controlType = calc.getEdgeById(e.getStoreId()).getControlType();
            e.setAttribute("ControlType", controlType);
        }

        Node[] nodes = graphModel.getGraphVisible().getNodes().toArray();
        for(Node n : nodes)
        {
            n.setAttribute("ricci_forman", calc.getNodeById(n.getStoreId()).get("Ricci-Forman"));
            n.setAttribute("ricci_forman_directed", calc.getNodeById(n.getStoreId()).get("directed Ricci-Forman"));
            n.setAttribute("signed_control", calc.getNodeById(n.getStoreId()).get("signed-control curvature"));
            n.setAttribute("negative_ricci_forman", -1.0*calc.getNodeById(n.getStoreId()).get("Ricci-Forman"));
            n.setAttribute("negative_ricci_forman_directed", -1.0*calc.getNodeById(n.getStoreId()).get("directed Ricci-Forman"));
            n.setAttribute("negative_signed_control", -1.0*calc.getNodeById(n.getStoreId()).get("signed-control curvature"));
        }
    }

    public double getAverageRicciForman()
    {
        return calc.getAverageRicciForman();
    }

    public String setRandomizationOfStuff(String proportions, boolean randomize_directions)
    {
        if(calc == null)
            return "Calculator not initialized";
        Pattern pattern = Pattern.compile("\\d+\\.?\\d+");    
        Matcher matcher = pattern.matcher(proportions);
        ArrayList<Double> props = new ArrayList<Double>();
        while (matcher.find())
        {    
            Double val = Double.parseDouble(matcher.group());
            if(val == null)
                return "Couldn't parse double";
            props.add(val);
        }

        if(props.size() == 2)
        {
            calc.setRandomizationOfControlType(props.get(0).doubleValue(), props.get(1).doubleValue());
            if(randomize_directions)
                calc.setRandomizationOfDirections();
            return "Successful randomization setting";
        }
        calc.setNoRandomization();
        return "No randomization";
    }

    @Override
    public String getReport() {
        

        // String percentiles_e = "{" + Double.toString(calc.edges_ricci_forman_stats.percentiles[0]);
        // for(int i=0; i<100; i++)
        // {
        //     percentiles_e += ","+Double.toString(calc.edges_ricci_forman_stats.percentiles[i]);
        // }
        // percentiles_e = percentiles_e + "}";
        // String edges_summary = "mean = " + Double.toString(calc.edges_ricci_forman_stats.mean) + "\n"
        //                 +"variance = " + Double.toString(calc.edges_ricci_forman_stats.variance) + "\n"
        //                 +"standarddev = " + Double.toString(calc.edges_ricci_forman_stats.stddev) + "\n"
        //                 +"median = " + Double.toString(calc.edges_ricci_forman_stats.median) + "\n"
        //                 +"min = " + Double.toString(calc.edges_ricci_forman_stats.min) + "\n"
        //                 +"max = " + Double.toString(calc.edges_ricci_forman_stats.max) + "\n"
        //                 +"skewness = " + Double.toString(calc.edges_ricci_forman_stats.skew) + "\n"
        //                 +"geometricmean = " + Double.toString(calc.edges_ricci_forman_stats.geometricmean) + "\n"
        //                 +"norm = " + Double.toString(calc.edges_ricci_forman_stats.norm) + "\n"
        //                 +"percentiles = " + percentiles_e+"\n";        

        // String percentiles_ed = "{" + Double.toString(calc.edges_ricci_forman_directed_stats.percentiles[0]);
        // for(int i=0; i<100; i++)
        // {
        //     percentiles_ed += ","+Double.toString(calc.edges_ricci_forman_directed_stats.percentiles[i]);
        // }
        // percentiles_ed = percentiles_ed + "}";
        // String edges_summary_dir = "mean = " + Double.toString(calc.edges_ricci_forman_directed_stats.mean) + "\n"
        //                 +"variance = " + Double.toString(calc.edges_ricci_forman_directed_stats.variance) + "\n"
        //                 +"standarddev = " + Double.toString(calc.edges_ricci_forman_directed_stats.stddev) + "\n"
        //                 +"median = " + Double.toString(calc.edges_ricci_forman_directed_stats.median) + "\n"
        //                 +"min = " + Double.toString(calc.edges_ricci_forman_directed_stats.min) + "\n"
        //                 +"max = " + Double.toString(calc.edges_ricci_forman_directed_stats.max) + "\n"
        //                 +"skewness = " + Double.toString(calc.edges_ricci_forman_directed_stats.skew) + "\n"
        //                 +"geometricmean = " + Double.toString(calc.edges_ricci_forman_directed_stats.geometricmean) + "\n"
        //                 +"norm = " + Double.toString(calc.edges_ricci_forman_directed_stats.norm) + "\n"
        //                 +"percentiles = " + percentiles_ed+"\n";                

        // String percentiles_n = "{" + Double.toString(calc.nodes_ricci_forman_stats.percentiles[0]);
        // for(int i=0; i<100; i++)
        // {
        //     percentiles_n += ","+Double.toString(calc.nodes_ricci_forman_stats.percentiles[i]);
        // }
        // percentiles_n = percentiles_n + "}";
        // String nodes_summary = "mean = " + Double.toString(calc.nodes_ricci_forman_stats.mean) + "\n"
        //                 +"variance = " + Double.toString(calc.nodes_ricci_forman_stats.variance) + "\n"
        //                 +"standarddev = " + Double.toString(calc.nodes_ricci_forman_stats.stddev) + "\n"
        //                 +"median = " + Double.toString(calc.nodes_ricci_forman_stats.median) + "\n"
        //                 +"min = " + Double.toString(calc.nodes_ricci_forman_stats.min) + "\n"
        //                 +"max = " + Double.toString(calc.nodes_ricci_forman_stats.max) + "\n"
        //                 +"skewness = " + Double.toString(calc.nodes_ricci_forman_stats.skew) + "\n"
        //                 +"geometricmean = " + Double.toString(calc.nodes_ricci_forman_stats.geometricmean) + "\n"
        //                 +"norm = " + Double.toString(calc.nodes_ricci_forman_stats.norm) + "\n"
        //                 +"percentiles = " + percentiles_n+"\n";                
        
        // String percentiles_nd = "{" + Double.toString(calc.nodes_ricci_forman_directed_stats.percentiles[0]);
        // for(int i=0; i<100; i++)
        // {
        //     percentiles_nd += ","+Double.toString(calc.nodes_ricci_forman_directed_stats.percentiles[i]);
        // }
        // percentiles_nd = percentiles_nd + "}";
        // String nodes_summary_dir = "mean = " + Double.toString(calc.nodes_ricci_forman_directed_stats.mean) + "\n"
        //                 +"variance = " + Double.toString(calc.nodes_ricci_forman_directed_stats.variance) + "\n"
        //                 +"standarddev = " + Double.toString(calc.nodes_ricci_forman_directed_stats.stddev) + "\n"
        //                 +"median = " + Double.toString(calc.nodes_ricci_forman_directed_stats.median) + "\n"
        //                 +"min = " + Double.toString(calc.nodes_ricci_forman_directed_stats.min) + "\n"
        //                 +"max = " + Double.toString(calc.nodes_ricci_forman_directed_stats.max) + "\n"
        //                 +"skewness = " + Double.toString(calc.nodes_ricci_forman_directed_stats.skew) + "\n"
        //                 +"geometricmean = " + Double.toString(calc.nodes_ricci_forman_directed_stats.geometricmean) + "\n"
        //                 +"norm = " + Double.toString(calc.nodes_ricci_forman_directed_stats.norm) + "\n"
        //                 +"percentiles = " + percentiles_nd+"\n";                
        

        //This is the HTML report shown when execution ends. 
        //One could add a distribution histogram for instance
                String report = "<HTML> <BODY> <h1></h1> "
                + "<hr>"
                + "<pre>"
                + "<code>"
                + calc.header_data() + "\n"
                + "Edge curvatures\n"
                + calc.edges_ricci_forman_stats.verbose_report() + "\n"
                + "Edge curvatures (directed version)\n"
                + calc.edges_ricci_forman_directed_stats.verbose_report() + "\n"
                + "Edge curvatures (signed control)\n"
                + calc.edges_ricci_forman_signed_control_stats.verbose_report() + "\n"
                + "Node curvatures\n"
                + calc.nodes_ricci_forman_stats.verbose_report() + "\n"
                + "Node curvatures (directed version)\n"
                + calc.nodes_ricci_forman_directed_stats.verbose_report()+"\n"
                + "Node curvatures (signed control)\n"
                + calc.nodes_ricci_forman_signed_control_stats.verbose_report()+"\n"
                + "Just the above numerical data:\n"
                + calc.edges_ricci_forman_stats.values_report()+"\n"
                + calc.edges_ricci_forman_directed_stats.values_report()+"\n"
                + calc.edges_ricci_forman_signed_control_stats.values_report()+"\n"
                + calc.nodes_ricci_forman_stats.values_report()+"\n"
                + calc.nodes_ricci_forman_directed_stats.values_report()+"\n"
                + calc.nodes_ricci_forman_signed_control_stats.values_report()+"\n"
                + "</code>"
                + "</pre>"
                + "<br>"
                + "<br />"
                + "</BODY></HTML>";
        return report;
    }
}
