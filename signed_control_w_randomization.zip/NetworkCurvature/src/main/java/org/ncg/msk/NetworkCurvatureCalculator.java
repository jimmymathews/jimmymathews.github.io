package org.ncg.msk;

import java.util.*;
import org.apache.commons.math.stat.descriptive.*;

//   This class calculates the Ricci-Forman directed/signed-control curvatures of a weighted or unweighted network.
//   It is relatively agnostic about the environment it is used in.
//   Import and export methods are provided to link up this calculator with the environment in which it will be used.

public class NetworkCurvatureCalculator
{
	ArrayList<NodeNC> nodes = new ArrayList<NodeNC>();
	ArrayList<EdgeNC> edges = new ArrayList<EdgeNC>();
	double activationProbability=-1;
	double repressionProbability=-1;
	boolean randomizationOfControlType = false;  //Determines whether the main pipeline will first create random values for the "control type" flags
	boolean randomizationOfDirections = false;
	int zero_edge_weight_count = 0;

	public StatsSummary nodes_ricci_forman_stats;
	public StatsSummary nodes_ricci_forman_directed_stats;
	public StatsSummary edges_ricci_forman_stats;
	public StatsSummary edges_ricci_forman_directed_stats;

	public StatsSummary nodes_ricci_forman_signed_control_stats;
	public StatsSummary edges_ricci_forman_signed_control_stats;

	public NetworkCurvatureCalculator()
	{
		nodes_ricci_forman_stats = new StatsSummary();
		nodes_ricci_forman_directed_stats = new StatsSummary();
		edges_ricci_forman_stats = new StatsSummary();
		edges_ricci_forman_directed_stats = new StatsSummary();
		
		nodes_ricci_forman_signed_control_stats = new StatsSummary();
		edges_ricci_forman_signed_control_stats = new StatsSummary();
	}

	//Contents:
	//   -Main calculations
	//   -Import methods
	//   -Export methods
	//   -Internal data structures

	//Main calculations
	//This function assumes that the nodes and edges ArrayLists have been populated with all of your network data

	public void calculateRicciFormanDirectedUndirected()
	{

 		considerRandomizingData();

		int activation_sum = 0;
		int repression_sum = 0;
		int dual_sum = 0;

		for(int i=0; i<edges.size(); i++)
		{
			EdgeNC e = edges.get(i);

			//just for statistics
			if(e.both())
				dual_sum++;
			else
			{
				if(e.activates())
					activation_sum++;
				else
					if(e.inhibits())
						repression_sum++;
			}

			NodeNC v1 = e.getSource();
			NodeNC v2 = e.getTarget();
			double we = e.getWeight();
			double wv1 = v1.getWeight();
			double wv2 = v2.getWeight();

			ArrayList<EdgeNC> v1neighbors = v1.getNeighbors();
			ArrayList<EdgeNC> v2neighbors = v2.getNeighbors();

			double tally_sc    = wv1 + wv2;
			double tally_dir   = wv1 + wv2;
			double tally_undir = wv1 + wv2;
		
			for(int j=0; j<v1neighbors.size(); j++)
			{
				EdgeNC ev1 = v1neighbors.get(j);
				double sign = ev1.control_sign() * e.control_sign();
				double wev1 = ev1.getWeight();
				if(wev1!=0)
					tally_undir -= sign * wv1 * Math.sqrt(we/wev1);
				else
					zero_edge_weight_count++;

				if(v1.is(ev1.getTarget()))
				{
					if(wev1!=0)
					{
						tally_dir -= 1.0 * wv1 * Math.sqrt(we/wev1);
						tally_sc  -= sign * wv1 * Math.sqrt(we/wev1);
						// sc means "signed-control curvature"
					}
					else
						zero_edge_weight_count++;
				}
			}
			for(int j=0; j<v2neighbors.size(); j++)
			{
				EdgeNC ev2 = v2neighbors.get(j);
				double sign = ev2.control_sign() * e.control_sign();
				double wev2 = ev2.getWeight();
				if(wev2!=0)
					tally_undir -= sign * wv2 * Math.sqrt(we/wev2);
				else
					zero_edge_weight_count++;

				if(v2.is(ev2.getSource()))
				{
					if(wev2!=0)
					{
						tally_dir -= 1.0 * wv2 * Math.sqrt(we/wev2);
						tally_sc  -= sign * wv2 * Math.sqrt(we/wev2);
					}
					else
						zero_edge_weight_count++;
				}
			}

			e.set("signed-control curvature",tally_sc);
			e.set("directed Ricci-Forman",tally_dir);
			e.set("Ricci-Forman",tally_undir);
		}

		int ttl = activation_sum + repression_sum + dual_sum;
		if(ttl!=0)
		{
			activationProbability = activation_sum*1.0 / ttl;
			repressionProbability = repression_sum*1.0 / ttl;
		}

		for(int i=0; i<nodes.size(); i++)
		{
			NodeNC n = nodes.get(i);
			ArrayList<EdgeNC> neighbors = n.getNeighbors();
			double tally_sc = 0;
			double tally_dir = 0;
			double tally_undir = 0;
			for(int j=0; j<neighbors.size(); j++)
			{
				tally_sc += neighbors.get(j).get("signed-control curvature");
				tally_dir += neighbors.get(j).get("directed Ricci-Forman");
				tally_undir += neighbors.get(j).get("Ricci-Forman");
			}
			n.set("signed-control curvature",tally_sc);
			n.set("directed Ricci-Forman",tally_dir);
			n.set("Ricci-Forman",tally_undir);
		}
		calculateStatistics();
	}

	public void considerRandomizingData()
	{
		if(randomizationOfControlType)
		{
			for(int i=0; i<edges.size(); i++)
			{
				double rando = Math.random();
				if(rando < activationProbability)
				{
					edges.get(i).setControlType("activation");
				}
				else if(rando>= activationProbability && rando < activationProbability+repressionProbability)
				{
					edges.get(i).setControlType("repression");
				}
				else
					edges.get(i).setControlType("dual");
			}
		}

		if(randomizationOfDirections)
		{
			for(int i=0; i<edges.size(); i++)
			{
				double rando = Math.random();
				if(rando < 0.5)
				{
					edges.get(i).reverseDirection();
				}
				else
				{
					//edges.get(i).dontReverseDirection() !
				}
			}
		}
	};

	public void calculateStatistics()
	{
		for(int i=0; i<nodes.size();i++)
		{
			nodes_ricci_forman_stats.addValue(nodes.get(i).get("Ricci-Forman"));
			nodes_ricci_forman_directed_stats.addValue(nodes.get(i).get("directed Ricci-Forman"));

			nodes_ricci_forman_signed_control_stats.addValue(nodes.get(i).get("signed-control curvature"));
		}

		for(int i=0; i<edges.size();i++)
		{
			edges_ricci_forman_stats.addValue(edges.get(i).get("Ricci-Forman"));
			edges_ricci_forman_directed_stats.addValue(edges.get(i).get("directed Ricci-Forman"));

			edges_ricci_forman_signed_control_stats.addValue(edges.get(i).get("signed-control curvature"));
		}


		nodes_ricci_forman_stats.calculate();
		nodes_ricci_forman_directed_stats.calculate();
		edges_ricci_forman_stats.calculate();
		edges_ricci_forman_directed_stats.calculate();

		nodes_ricci_forman_signed_control_stats.calculate();
		edges_ricci_forman_signed_control_stats.calculate();
	}

	//Import methods, called by an external user of this calculator to give their graph data to the calculator
	public void setRandomizationOfControlType(double activation, double repression)
	{
		activationProbability = activation;
		repressionProbability = repression;
		randomizationOfControlType = true;
		if(activation == -1 && repression == -1)
			randomizationOfControlType = false;
	}

	public void setRandomizationOfDirections()
	{
		randomizationOfDirections = true;
	}

	public void setNoRandomization()
	{
		activationProbability=-1;
		repressionProbability=-1;
		randomizationOfControlType = false;
		randomizationOfDirections = false;
		zero_edge_weight_count = 0;

		for(int i=0; i<edges.size();i++)
		{
			edges.get(i).setControlType("activation");
		}				
	}

	public void addNode(double weight, int id)
	{
		nodes.add(new NodeNC(weight, id));
	}

	public void addEdge(int sourceId, int targetId, double weight, int id, String control_type)
	{
		NodeNC source = getNodeById(sourceId);
		NodeNC target = getNodeById(targetId);
		EdgeNC newedge = new EdgeNC(source, target, weight, id, control_type);
		source.addEdge(newedge);
		target.addEdge(newedge);
		edges.add(newedge);
	}

	public NodeNC getNodeById(int id)
	{
		for(int i=0; i<nodes.size();i++)
		{
			if(nodes.get(i).getId() == id)
				return nodes.get(i);
		}
		return null;
	}

	public EdgeNC getEdgeById(int id)
	{
		for(int i=0; i<edges.size();i++)
		{
			if(edges.get(i).getId() == id)
				return edges.get(i);
		}
		return null;
	}

	//Miscellaneous export methods
	public double getAverageRicciForman()
	{				//The Ricci-Forman curvature is a primarily edge-based concept, so the edge-based average is provided here
		double tally = 0;
		for(int i=0; i<edges.size(); i++)
			tally += edges.get(i).get("Ricci-Forman");
		if(edges.size()==0)
			return -1000001.0;
		return tally/edges.size();
	}

	// Sample export method, called from outside:
	// 
    //  public void importResults(GraphModel graphModel, NetworkCurvatureCalculator calc)
    // {
    //     Edge[] edges = graphModel.getGraphVisible().getEdges().toArray();
    //     for(Edge e : edges)
    //     {
    //         e.setAttribute("ricci_forman", calc.getEdgeById(e.getStoreId()).get("Ricci-Forman"));                     // <---- get("Ricci-Forman") etc. are the main things
    //         e.setAttribute("ricci_forman_directed", calc.getEdgeById(e.getStoreId()).get("directed Ricci-Forman"));
    //         e.setAttribute("negative_ricci_forman", -1.0*calc.getEdgeById(e.getStoreId()).get("Ricci-Forman"));
    //         e.setAttribute("negative_ricci_forman_directed", -1.0*calc.getEdgeById(e.getStoreId()).get("directed Ricci-Forman"));

    //         String controlType = calc.getEdgeById(e.getStoreId()).getControlType();
    //         e.setAttribute("ControlType", controlType);
    //     }

    //     Node[] nodes = graphModel.getGraphVisible().getNodes().toArray();
    //     for(Node n : nodes)
    //     {
    //         n.setAttribute("ricci_forman", calc.getNodeById(n.getStoreId()).get("Ricci-Forman"));
    //         n.setAttribute("ricci_forman_directed", calc.getNodeById(n.getStoreId()).get("directed Ricci-Forman"));
    //         n.setAttribute("negative_ricci_forman", -1.0*calc.getNodeById(n.getStoreId()).get("Ricci-Forman"));
    //         n.setAttribute("negative_ricci_forman_directed", -1.0*calc.getNodeById(n.getStoreId()).get("directed Ricci-Forman"));
    //     }
    // }



	int getNumNodes()
	{
		return nodes.size();
	}

	int getNumEdges()
	{
		return edges.size();
	}

	String header_data()
	{
		String summary = "numberOfNodes = " + Integer.toString(getNumNodes()) + "\n"
						+"numberOfEdges = " + Integer.toString(getNumEdges()) + "\n"
						+"connectionProbability = " + Double.toString((getNumEdges()*1.0)/( (getNumNodes()-1)*(getNumNodes())/2  )) + "\n"
						+"activationProbability = " + Double.toString(activationProbability) + "\n"
						+"repressionProbability = " + Double.toString(repressionProbability) + "\n"
						+"So, proportions:    " + Double.toString(activationProbability)+","+Double.toString(repressionProbability) + "\n";
		return summary;							
	}


	//Data structures internal to the calculator
	class NetworkElement
	{
		double w;
		int id;
		ArrayList<ElementMetric> metrics = new ArrayList<ElementMetric>();
		
		NetworkElement(double weight, int identifier)
		{
			w  = weight;
			id = identifier;
			metrics.add(new ElementMetric(3.1415,"Ricci-Forman"));
			metrics.add(new ElementMetric(3.1415,"directed Ricci-Forman"));
			metrics.add(new ElementMetric(3.1415,"signed-control curvature"));
		}

		double	getWeight()	{return w;}
		int		getId()		{return id;}

		void set(String name, double val)
		{
			for(int i=0; i<metrics.size(); i++)
			{
				if(metrics.get(i).name.equals(name))
					metrics.get(i).value = val;
			}
		}
		double get(String name)
		{
			for(int i=0; i<metrics.size(); i++)
			{
				if(metrics.get(i).name.equals(name))
					return metrics.get(i).value;
			}
			return 3.1415;
		}
	}

	class ElementMetric
	{
		public double value;
		public String name;
		ElementMetric(double v, String n)
		{
			value = v;
			name = n;
		}
	}

	class EdgeNC extends NetworkElement
	{
		NodeNC s;
		NodeNC t;
		String control_type; //activation or inhibition
		
		EdgeNC(NodeNC source, NodeNC target, double weight, int identifier)
		{
			super(weight, identifier);
			s  = source;
			t  = target;
		}

		EdgeNC(NodeNC source, NodeNC target, double weight, int identifier, String ct)
		{
			this(source, target, weight, identifier);
			control_type = ct;
		}
		
		NodeNC getSource() {return s;}
		NodeNC getTarget() {return t;}

		boolean is(EdgeNC other)
		{
			return other.getId() == id;
		}

		void reverseDirection()
		{
			NodeNC swap = s;
			s = t;
			t = swap;
		}

		void setControlType(String type)
		{
			control_type = type;
		}

		String getControlType()
		{
			return control_type;
		}

		boolean activates()
		{
			return control_type.equals("activation") || control_type.equals("activator");
		}

		boolean inhibits() 
		{
			return control_type.equals("inhibition") || control_type.equals("inhibitor") || 
				control_type.equals("repression") || control_type.equals("repressor");
		}

		boolean both()
		{
			return control_type.equals("dual") || control_type.equals("both");
		}

		double control_sign()
		{
			if(this.activates())
				return 1.0;
			if(this.inhibits())
				return -1.0;
			// if(this.both())
				//...
			return 1.0; //default activation
		}
	}

	class NodeNC extends NetworkElement
	{
		ArrayList<EdgeNC> neighboringEdges = new ArrayList<EdgeNC>();

		NodeNC(double weight, int identifier)
		{
			super(weight, identifier);
		}

		boolean is(NodeNC other)
		{
			return other.getId() == id;
		}

		void addEdge(EdgeNC e)
		{
			neighboringEdges.add(e);
		}

		ArrayList<EdgeNC> getNeighbors()	{return neighboringEdges;}
	}

	class StatsSummary
	{
		public double mean;
		public double variance;
		public double stddev;
		public double median;
		public double min;
		public double max;
		public double skew;
		public double geometricmean;
		public double norm;
		public double[] percentiles;

		DescriptiveStatistics stats;

		StatsSummary()
		{
			stats = new DescriptiveStatistics();
		}

		void addValue(double val)
		{
			stats.addValue(val);
		}

		void calculate()
		{
			mean = stats.getMean();
			variance = stats.getVariance();
			stddev = stats.getStandardDeviation();
			median = stats.getPercentile(50);
			min = stats.getMin();
			max = stats.getMax();
			skew = stats.getSkewness();
			geometricmean = stats.getGeometricMean();
			norm = Math.sqrt(stats.getSumsq());			

			percentiles = new double[100];
			for(int i=0; i<percentiles.length; i++)
			{
				percentiles[i] = stats.getPercentile(i+1);
			}
		}

		String verbose_report()
		{
			String summary = "mean = " + Double.toString(mean) + "\n"
						+"variance = " + Double.toString(variance) + "\n"
						+"standarddev = " + Double.toString(stddev) + "\n"
						+"median = " + Double.toString(median) + "\n"
						+"min = " + Double.toString(min) + "\n"
						+"max = " + Double.toString(max) + "\n"
						+"skewness = " + Double.toString(skew) + "\n"
						+"norm = " + Double.toString(norm) + "\n";
			return summary;
		}
		String values_report()
		{
			String summary = Double.toString(mean) + "\n"
						+ Double.toString(variance) + "\n"
						+ Double.toString(stddev) + "\n"
						+ Double.toString(median) + "\n"
						+ Double.toString(min) + "\n"
						+ Double.toString(max) + "\n"
						+ Double.toString(skew) + "\n"
						+ Double.toString(norm) + "\n";
			return summary;	
		}
	}

}
